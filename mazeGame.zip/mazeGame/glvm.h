#ifndef GLVM_H
#define GLVM_H

#pragma once

#include <cmath>

namespace glvm {
	const double PI = 3.14159265359;

	class vec2 {
	public:
		float v[2];

		vec2() : v{ 0, 0 } {}
		vec2(float x, float y) : v{ x, y } {}
	};

	class vec3 {
	public:
		float v[3];

		vec3() : v{ 0, 0, 0 } {}
		vec3(float x, float y, float z) : v{ x, y, z } {}

		vec3 operator*(const float s) { return vec3(v[0] * s, v[1] * s, v[2] * s); }
		vec3 operator*(const double s) { return vec3(v[0] * s, v[1] * s, v[2] * s); }
		vec3 operator+(const float s) { return vec3(v[0] + s, v[1] + s, v[2] + s); }
		vec3 operator+(const vec3& vv) { return vec3(v[0] + vv.v[0], v[1] + vv.v[1], v[2] + vv.v[2]); }
		vec3 operator/(const float s) { return vec3(v[0] / s, v[1] / s, v[2] / s); }
		void operator=(const vec3& vv) { v[0] = vv.v[0]; v[1] = vv.v[1]; v[2] = vv.v[2]; }
		void operator=(const float s) { v[0] = s; v[1] = s; v[2] = s; }
		void operator*=(const vec3& vv) { v[0] *= vv.v[0]; v[1] *= vv.v[1]; v[2] *= vv.v[2]; }
		void operator*=(const float s) { v[0] *= s; v[1] *= s; v[2] *= s; }
		void operator+=(const vec3& vv) { v[0] += vv.v[0]; v[1] += vv.v[1]; v[2] += vv.v[2]; }
		vec3 operator-() { return vec3(-v[0], -v[1], -v[2]); }
	};

	class vec4 {
	public:
		float v[4];

		vec4() : v{ 0, 0, 0, 0 } {}
		vec4(float x, float y, float z, float w) : v{ x, y, z, w } {}
		vec4(const vec3& vv, float w) : v{ vv.v[0], vv.v[1], vv.v[2], w } {}
	};

	class mat4 {
	public:
		float m[16];

		mat4() : m{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } {}
		mat4 operator*(const mat4& mm) {
			mat4 temp;
			float sum = 0;

			for (int i = 0; i < 4; ++i) {
				for (int j = 0; j < 4; ++j) {
					for (int k = 0; k < 4; ++k) {
						sum += m[k * 4 + i] * mm.m[j * 4 + k];
					}

					temp.m[j * 4 + i] = sum;
					sum = 0;
				}
			}

			return temp;
		}
		void operator=(const mat4& mm) { for (int i = 0; i < 16; ++i) m[i] = mm.m[i]; }
	};

	inline float dot(vec3 a, vec3 b) { return a.v[0] * b.v[0] + a.v[1] * b.v[1] + a.v[2] * b.v[2]; }
	inline vec3 cross(vec3& a, vec3& b) {
		vec3 temp;
		temp.v[0] = a.v[1] * b.v[2] - a.v[2] * b.v[1];
		temp.v[1] = a.v[2] * b.v[0] - a.v[0] * b.v[2];
		temp.v[2] = a.v[0] * b.v[1] - a.v[1] * b.v[0];

		return temp;
	}
	inline float magnitude(vec3 v) { return sqrt(v.v[0] * v.v[0] + v.v[1] * v.v[1] + v.v[2] * v.v[2]); }
	inline vec3 normalize(vec3 v) {
		vec3 temp;
		float length = magnitude(v);

		if (length != 0) {
			temp = v / length;
		}
		else {
			temp = 0.0f;
		}

		for (int i = 0; i < 3; ++i) {
			if (fabs(temp.v[i]) < 0.0000001) temp.v[i] = 0;
		}

		return temp;
	}

	inline mat4 identityMatrix() {
		mat4 temp;
		temp.m[0] = 1;
		temp.m[5] = 1;
		temp.m[10] = 1;
		temp.m[15] = 1;

		return temp;
	}

	inline mat4 translationMatrix(vec3 v) {
		mat4 temp = identityMatrix();
		temp.m[12] = v.v[0];
		temp.m[13] = v.v[1];
		temp.m[14] = v.v[2];

		return temp;
	}
	inline mat4 rotationXMatrix(float angle) {
		mat4 temp = identityMatrix();
		temp.m[5] = cos(angle * PI / 180);
		temp.m[9] = sin(angle * PI / 180);
		temp.m[6] = -sin(angle * PI / 180);
		temp.m[10] = cos(angle * PI / 180);

		return temp;
	}
	inline mat4 rotationYMatrix(float angle) {
		mat4 temp = identityMatrix();
		temp.m[0] = cos(angle * PI / 180);
		temp.m[8] = -sin(angle * PI / 180);
		temp.m[2] = sin(angle * PI / 180);
		temp.m[10] = cos(angle * PI / 180);

		return temp;
	}
	inline mat4 rotationZMatrix(float angle) {
		mat4 temp = identityMatrix();
		temp.m[0] = cos(PI * 3.14 / 180);
		temp.m[4] = sin(PI * 3.14 / 180);
		temp.m[1] = -sin(PI * 3.14 / 180);
		temp.m[5] = cos(PI * 3.14 / 180);

		return temp;
	}
	inline mat4 scaleMatrix(vec3 v) {
		mat4 temp = identityMatrix();

		temp.m[0] = v.v[0];
		temp.m[5] = v.v[1];
		temp.m[10] = v.v[2];

		return temp;
	}

	inline mat4 projectionPerspectiveMatrix(float near, float far, float fov, int width, int height) {
		mat4 temp;

		float aspect = (float)height / (float)width;
		float Sx = 1 / tan((fov * 0.5f) * 3.14 / 180) * aspect;
		float Sy = 1 / tan((fov * 0.5f) * 3.14 / 180);
		float Sz = -(far + near) / (far - near);
		float Pz = -(2.0 * far * near) / (far - near);

		temp.m[0] = Sx;
		temp.m[5] = Sy;
		temp.m[10] = Sz;
		temp.m[11] = -1;
		temp.m[14] = Pz;
		temp.m[15] = 0;

		return temp;
	}

	inline mat4 projectionOrthographic(float left, float right, float bottom, float top, float near, float far) {
		mat4 temp;

		temp.m[0] = 2.0f / (right - left);
		temp.m[5] = 2.0f / (top - bottom);
		temp.m[10] = -2.0f / (far - near);
		temp.m[12] = -(right + left) / (right - left);
		temp.m[13] = -(top + bottom) / (top - bottom);
		temp.m[14] = -(far + near) / (far - near);
		temp.m[15] = 1;

		return temp;
	}
}

#endif