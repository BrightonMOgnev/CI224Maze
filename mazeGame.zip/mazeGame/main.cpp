#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cctype>
#include <map>

#include <GL/glew.h>
#define GLFW_DLL
#include <GLFW/glfw3.h>

#include "glvm.h"

#include <ft2build.h>
#include FT_FREETYPE_H

//  || 

// Settings for the game window, using 16:9 aspect 720p.
GLFWwindow* window = nullptr;
int windowWidth = 1280;
int windowHeight = 720;

/*	----- VERTEX SHADER DATA -----
	This is the vertex shader data, writen in one continous string.
	The best way to handle shaders is from separate files, but to simplify the project (to meet the deadline) I combined everything into one C++ file.
	A vertex shader defines where the vertecies are in the game world.
	Before sending the information about vector position in the program, I'm multiplying it by:
	MODEL matrix (defines position of the object),
	VIEW matrix (defines position of the camera) and
	PROJECTION matrix (defines how the world is projected).
*/
const char* vertexShaderData =
"#version 330\n"
"in layout (location = 0) vec3 inVector;"
"in layout (location = 1) vec3 vectorNormal;"
"uniform mat4 viewMatrix, projectionMatrix, modelMatrix;"
"void main() {"
"	gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(inVector, 1.0);"
"}";

const char* fontVertexShaderData =
"#version 330\n"
"in layout (location = 0) vec4 inVector;"
"out vec2 texCoords;"
"uniform mat4 projectionMatrix;"
"void main() {"
"	gl_Position = projectionMatrix * vec4(inVector.xy, 0.0, 1.0);"
"	texCoords = inVector.zw;"
"}";

/*	----- FRAGMENT SHADER DATA -----
	Fragment shader is the second of two necessary shaders (first is vertex) I had to write.
	It defines how to color a particular object based on its color, material, light, reflection etc. 
*/
const char* fragmentShaderData =
"#version 330\n"
"uniform vec3 color;"
"out vec4 fragColor;"
"void main() {"
"	fragColor = vec4(color, 1.0);"
"}";

const char* fontFragmentShaderData =
"#version 330\n"
"in vec2 texCoords;"
"out vec4 fragColor;"
"uniform sampler2D text;"
"uniform vec3 textColor;"
"void main() {"
"	vec4 sampled = vec4(1.0, 1.0, 1.0, texture(text, texCoords).r);"
"	fragColor = vec4(textColor, 1.0) * sampled;"
"}";

// Shaders handlers used as reference variables of created shaders.
GLuint vertexShader;
GLuint fragmentShader;
GLuint shaderProgram;
GLuint fontVertexShader;
GLuint fontFragmentShader;
GLuint fontShaderProgram;

// Location variables are used to store the location of the uniform variables in shaders.
// I created a few uniform variables (for example viewMatrix, modelMatrix), to be able to amend the content of shader variables in real-time.
GLuint locationViewMatrix;
GLuint locationProjectionMatrix;
GLuint locationModelMatrix;
GLuint locationColor;
GLuint fontLocationProjectionMatrix;
GLuint fontLocationSamplerText;
GLuint fontLocationTextColor;

// Variables for text.
// Note that text position has to be adjusted when changing resolution of game window.
GLuint textVBO;
GLuint textVAO;
glvm::vec2 textPosition(10, 690);
glvm::vec3 textColor(0, 0, 0);
std::string coinsNumberText = "Coins: 0";

// Camera variables (for single camera).
// cameraMaxSpeed is used for movement velocity calculations; cameraMaxTorque is used for camera rotation calculations.
glvm::vec3 cameraPosition(10, 5, 25);
glvm::vec3 cameraRotation(0, 0, 0);
glvm::vec3 cameraVelocity(0, 0, 0);
glvm::vec3 cameraTorque(0, 0, 0);
float cameraMaxSpeed = 15.0f;
float cameraMaxTorque = 150.0f;

/* Set up two matricies: VIEW and PROJECTION.
The view matrix contains information about camera position, rotation etc.
The projection matrix contains information about how to display a 3D game space to a 2D screen.
I'm using perspective view for this game to make navigating the maze easy. */
glvm::mat4 cameraViewMatrix;
glvm::mat4 cameraProjectionMatrix;

// Position of the maze (model matrix is created later on).
glvm::vec3 mazePosition(0, 0, 0);

// Class for the coins in the level (using low poly "spheres" as coins).
// Stores initial position vectors and "visible" property used to provide visual feedback for collisions.
class Sphere {
public:
	Sphere() {
		position = glvm::vec3(0, 0, 0);
		visible = true;
	}

	Sphere(glvm::vec3 p) {
		position = p;
		visible = true;
	}

	glvm::vec3 position;
	bool visible;
};

std::vector<Sphere> coins;
int coinGathered = 0;

// Using delta time to ensure game runs as expected at any framerate.
double deltaTime = 0.0;

// Class for meshes.
class Mesh {
public:
	// Variables for storing mesh vertices, normals (didn't used them in this program), and indices.
	std::vector<glvm::vec3> vertices;
	std::vector<glvm::vec3> normals;
	std::vector<GLuint> indices;

	// Loads the file from specified path.
	int loadFromFile(const char* path) {
		std::ifstream file;
		file.open(path);

		// Returns error if fail wasn't found.
		if (!file.is_open()) {
			std::cout << "Failed to open file: " << path << "!\n";
			return -1;
		}

		std::vector<GLint> indexedNormals;
		std::vector<glvm::vec3> allNormals;

		while (!file.eof()) {
			// Opens the .obj file and separates data using the first word of each line (markers).
			std::string buffer;
			file >> buffer;

			// "v" stands for vertex.
			if (buffer == "v") {
				float v[3];
				file >> v[0] >> v[1] >> v[2];
				vertices.push_back(glvm::vec3(v[0], v[1], v[2]));
			}
			// "vn" is the normal of one vertex.
			if (buffer == "vn") {
				float vn[3];
				file >> vn[0] >> vn[1] >> vn[2];
				allNormals.push_back(glvm::vec3(vn[0], vn[1], vn[2]));
			}
			// For each vertex of a triangle, "f" stores three indicies in a format such as 8/12/7.
			// The first number picks the right vertex to use (from "v" lines in .obj file).
			// The second number stores the texture coordinate (not used in this program).
			// The last number picks the right vertex normal to use (from "vn" lines in .obj file).
			if (buffer == "f") {
				unsigned int v[3] = { 0, 0, 0 };
				int in = 0;
				for (int i = 0; i < 3; ++i) {
					file >> v[i];
					while (!isdigit(file.peek())) {
						file.ignore(1);
					}
					file >> in;

					// A conversion is needed or the objects won't load correctly (openGL index start to 1, not to 0 like in C++).
					// Therefore I subtract 1 from the indicies used.
					indices.push_back(v[i] - 1);
					indexedNormals.push_back(in - 1);
				}
				while (file.get() != '\n');}
		}

		for (int i = 0; i < indexedNormals.size(); ++i) {
			// Push back normals from file in the order of the vertex normal indices.
			normals.push_back(allNormals[indexedNormals[i]]);
		}

		return 0;
	}
};

// Tests if the point is on the right side with regards to a side of a 2D trianle in 3D space.
bool isSameSide(glvm::vec3 point, glvm::vec3 a, glvm::vec3 b, glvm::vec3 c) {
	glvm::vec3 ab = c + -b;
	glvm::vec3 ac = a + -b;
	glvm::vec3 ap = point + -b;
	glvm::vec3 cross0 = glvm::cross(ab, ac);
	glvm::vec3 cross1 = glvm::cross(ab, ap);

	if (glvm::dot(cross1, cross0) >= 0) return true;

	return false;
}

// Simple method to test if a point is inside a 2D triangle.
bool isPointIn2DTriangle(glvm::vec3 point, glvm::vec3 v1, glvm::vec3 v2, glvm::vec3 v3) {
	glvm::vec3 U = v2 + -v1;
	glvm::vec3 P = v3 + -v1;

	glvm::vec3 N = glvm::normalize(glvm::cross(U, P));

	static bool test = false;
	if (!test) {
		std::cout << "Normalized x: " << N.v[0] << " y: " << N.v[1] << " z: " << N.v[2] << '\n';
		test = true;
	}

	float onPlane = glvm::dot(-point + v1, N);

	// Final check.
	// Test has to be done for each triangle side.
	if (onPlane >= -0.5 && onPlane <= 1) {
		if (isSameSide(point, v1, v2, v3) && isSameSide(point, v2, v3, v1) && isSameSide(point, v3, v1, v2)) {
			return true;
		}
	}

	return false;
}

typedef struct Character {
	GLuint textureID;
	glvm::vec2 size;
	glvm::vec2 bearing;
	GLuint advance;
};

//Oswald font used for final game.
std::map<GLchar, Character> oswaldCharacters;

int main() {
	// Initialize GLFW3.
	if (!glfwInit()) {
		fprintf(stderr, "ERROR: Couldn't initialize GLFW3!\nTerminating...\n");
		return 1;
	}

	// Create GLFW3 window
	window = glfwCreateWindow(windowWidth, windowHeight, "GLFW3 WINDOW", NULL, NULL);
	if (!window) {
		fprintf(stderr, "ERROR: Couldn't create GLFW3 window!\nTerminating...\n");
		glfwTerminate();
		return 1;
	}

	glfwMakeContextCurrent(window);
	
	// Start GLEW.
	glewExperimental = true;
	glewInit();

	// Load and compile shaders.
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderData, NULL);
	glCompileShader(vertexShader);

	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderData, NULL);
	glCompileShader(fragmentShader);

	// Create and link shader program.
	shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, fragmentShader);
	glAttachShader(shaderProgram, vertexShader);
	glLinkProgram(shaderProgram);

	// Get uniform locations from shader.
	locationViewMatrix = glGetUniformLocation(shaderProgram, "viewMatrix");
	locationProjectionMatrix = glGetUniformLocation(shaderProgram, "projectionMatrix");
	locationModelMatrix = glGetUniformLocation(shaderProgram, "modelMatrix");
	locationColor = glGetUniformLocation(shaderProgram, "color");

	glUseProgram(shaderProgram);

	// Setup projection matrix.
	cameraProjectionMatrix = glvm::projectionPerspectiveMatrix(0.1f, 100.0f, 67.0f, windowWidth, windowHeight);
	glUniformMatrix4fv(locationProjectionMatrix, 1, GL_FALSE, cameraProjectionMatrix.m);

	// ----- LOADING FILES -----
	//Loading the maze.
	Mesh maze;
	maze.loadFromFile("obj/maze.obj");
	GLuint mazeVBO;
	GLuint mazeVAO;
	GLuint mazeIBO;

	glGenVertexArrays(1, &mazeVAO);
	glBindVertexArray(mazeVAO);

	glGenBuffers(1, &mazeVBO);
	glBindBuffer(GL_ARRAY_BUFFER, mazeVBO);
	glBufferData(GL_ARRAY_BUFFER, maze.vertices.size() * sizeof(glvm::vec3), &maze.vertices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, mazeVBO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)(0));

	glEnableVertexAttribArray(0);

	glGenBuffers(1, &mazeIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mazeIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, maze.indices.size() * sizeof(GLuint), &maze.indices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mazeIBO);

	//Loading the coins (spheres in the game).
	Mesh sphere;
	sphere.loadFromFile("obj/sphere.obj");
	GLuint sphereVBO;
	GLuint sphereVAO;
	GLuint sphereIBO;

	glGenVertexArrays(1, &sphereVAO);
	glBindVertexArray(sphereVAO);

	glGenBuffers(1, &sphereVBO);
	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
	glBufferData(GL_ARRAY_BUFFER, sphere.vertices.size() * sizeof(glvm::vec3), &sphere.vertices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)(0));

	glEnableVertexAttribArray(0);

	glGenBuffers(1, &sphereIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere.indices.size() * sizeof(GLuint), &sphere.indices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereIBO);

	// Setup coins on the map.
	coins.push_back(Sphere(glvm::vec3(2, 4, -2)));
	coins.push_back(Sphere(glvm::vec3(-6, 4, 6)));
	coins.push_back(Sphere(glvm::vec3(-6, 4, 14)));
	coins.push_back(Sphere(glvm::vec3(14, 4, 1)));
	coins.push_back(Sphere(glvm::vec3(14, 4, -5)));

	// For text rendering, I used the code from LearnOpenGL (Text Rendering article).
	// Setup font.
	FT_Library ft;
	if (FT_Init_FreeType(&ft)) {
		std::cout << "Couldn't initialize FreeType library!\n";
		return -1;
	}

	FT_Face oswaldFont;
	if (FT_New_Face(ft, "fonts/oswald.ttf", 0, &oswaldFont)) {
		std::cout << "Couldn't find font!\n";
		return -1;
	}

	FT_Set_Pixel_Sizes(oswaldFont, 0, 48);

	// Load 128 ASCII characters from the font.
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1); // Disable byte-alignment restriction.
	for (GLubyte i = 0; i < 128; ++i) {
		// Load character glyph.
		if (FT_Load_Char(oswaldFont, i, FT_LOAD_RENDER)) {
			std::cout << "Couldn't load glyph!\n";
			continue;
		}

		// Generate texture.
		GLuint texture;
		glGenTextures(1, &texture);
		glBindTexture(GL_TEXTURE_2D, texture);
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RED,
			oswaldFont->glyph->bitmap.width,
			oswaldFont->glyph->bitmap.rows,
			0,
			GL_RED,
			GL_UNSIGNED_BYTE,
			oswaldFont->glyph->bitmap.buffer
		);

		// Set texture options.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		Character character = {
			texture,
			glvm::vec2(oswaldFont->glyph->bitmap.width, oswaldFont->glyph->bitmap.rows),
			glvm::vec2(oswaldFont->glyph->bitmap_left, oswaldFont->glyph->bitmap_top),
			oswaldFont->glyph->advance.x
		};

		oswaldCharacters.insert(std::pair<GLchar, Character>(i, character));
	}

	FT_Done_Face(oswaldFont);
	FT_Done_FreeType(ft);

	// Setup shader for font.
	// Load and compile shaders.
	fontVertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(fontVertexShader, 1, &fontVertexShaderData, NULL);
	glCompileShader(fontVertexShader);

	fontFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fontFragmentShader, 1, &fontFragmentShaderData, NULL);
	glCompileShader(fontFragmentShader);

	// Create and link shader program.
	fontShaderProgram = glCreateProgram();
	glAttachShader(fontShaderProgram, fontFragmentShader);
	glAttachShader(fontShaderProgram, fontVertexShader);
	glLinkProgram(fontShaderProgram);

	// Get uniform locations from shader.
	fontLocationProjectionMatrix = glGetUniformLocation(fontShaderProgram, "projectionMatrix");
	fontLocationSamplerText = glGetUniformLocation(fontShaderProgram, "text");
	fontLocationTextColor = glGetUniformLocation(fontShaderProgram, "textColor");

	// Create orthographic view for text display.
	glvm::mat4 orthographic = glvm::projectionOrthographic(0, windowWidth, 0, windowHeight, -1, 1);

	// Setup buffers for text.
	glGenVertexArrays(1, &textVAO);
	glGenBuffers(1, &textVBO);

	glBindVertexArray(textVAO);
	glBindBuffer(GL_ARRAY_BUFFER, textVBO);

	// Allocate memory in dynamic VBO to use it later as 2D square for character.
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), (void*)(0));

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	// Screen (background) color.
	glClearColor(0.0f, 0.74f, 0.59f, 1.0f);

	glEnable(GL_DEPTH_TEST);
	glLineWidth(3);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	// Main game loop.
	while (!glfwWindowShouldClose(window)) {
		static double prevTime = glfwGetTime();
		double currTime = glfwGetTime();
		deltaTime = currTime - prevTime;
		prevTime = glfwGetTime();

		// ----- INPUT -----
		// These can be changed to GLFW_KEY_UP etc (instead of GLFW_KEY_W) if you want to play using arrow keys.
		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
			cameraVelocity.v[0] = sin(cameraRotation.v[1] * glvm::PI / 180) * cameraMaxSpeed;
			cameraVelocity.v[2] = -cos(cameraRotation.v[1] * glvm::PI / 180) * cameraMaxSpeed;
		}
		else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
			cameraVelocity.v[0] = -sin(cameraRotation.v[1] * glvm::PI / 180) * cameraMaxSpeed;
			cameraVelocity.v[2] = cos(cameraRotation.v[1] * glvm::PI / 180) * cameraMaxSpeed;
		}
		else {
			cameraVelocity.v[0] = 0;
			cameraVelocity.v[2] = 0;
		}

		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
			cameraTorque.v[1] = cameraMaxTorque;
		}
		else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
			cameraTorque.v[1] = -cameraMaxTorque;
		}
		else cameraTorque.v[1] = 0;

		// ---- GAME LOGIC -----
		cameraPosition += cameraVelocity * deltaTime;
		cameraRotation += cameraTorque * deltaTime;

		// Collision detection.
		for (int i = 0; i < maze.indices.size() / 3; ++i) {
			int v1 = maze.indices[i * 3], v2 = maze.indices[i * 3 + 1], v3 = maze.indices[i * 3 + 2];
			if (isPointIn2DTriangle(cameraPosition, maze.vertices[v1], maze.vertices[v2], maze.vertices[v3])) {
				cameraPosition += -cameraVelocity * deltaTime;
			}
		}

		// Collecting coins.
		for (int i = 0; i < coins.size(); ++i) {
			if (coins[i].visible) {
				if (sqrt(pow(cameraPosition.v[0] - coins[i].position.v[0], 2) + pow(cameraPosition.v[1] - coins[i].position.v[1], 2) +
					pow(cameraPosition.v[2] - coins[i].position.v[2], 2)) < 2) {
					coins[i].visible = false;
					coinGathered++;
					coinsNumberText = "Coins: " + std::to_string(coinGathered);
				}
			}
		}

		// Update camera view matrix by inverted camera position.
		cameraViewMatrix = glvm::rotationYMatrix(-cameraRotation.v[1]) * glvm::translationMatrix(-cameraPosition);

		// ----- RENDER -----
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		glUseProgram(shaderProgram);
		glUniformMatrix4fv(locationViewMatrix, 1, GL_FALSE, cameraViewMatrix.m);
		glUniformMatrix4fv(locationModelMatrix, 1, GL_FALSE, glvm::translationMatrix(mazePosition).m);
		glBindVertexArray(mazeVAO);

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glUniform3fv(locationColor, 1, glvm::vec3(0.04, 0.53, 0.91).v);
		glDrawElements(GL_TRIANGLES, maze.indices.size(), GL_UNSIGNED_INT, NULL);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glUniform3fv(locationColor, 1, glvm::vec3(0.0, 0.0, 0.0).v);
		glDrawElements(GL_TRIANGLES, maze.indices.size(), GL_UNSIGNED_INT, NULL);

		for (int i = 0; i < coins.size(); ++i) {
			if (coins[i].visible) {
				glUniformMatrix4fv(locationModelMatrix, 1, GL_FALSE, glvm::translationMatrix(coins[i].position).m);
				glBindVertexArray(sphereVAO);

				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
				glUniform3fv(locationColor, 1, glvm::vec3(0.99, 0.80, 0.43).v);
				glDrawElements(GL_TRIANGLES, sphere.indices.size(), GL_UNSIGNED_INT, NULL);
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
				glUniform3fv(locationColor, 1, glvm::vec3(0.0, 0.0, 0.0).v);
				glDrawElements(GL_TRIANGLES, sphere.indices.size(), GL_UNSIGNED_INT, NULL);
			}
		}

		// Render text.
		glUseProgram(fontShaderProgram);
		glUniformMatrix4fv(fontLocationProjectionMatrix, 1, GL_FALSE, orthographic.m);
		glUniform3fv(fontLocationTextColor, 1, textColor.v);
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glActiveTexture(GL_TEXTURE0);
		glBindVertexArray(textVAO);

		float scale = 0.5;
		float x = textPosition.v[0], y = textPosition.v[1];

		// Iterate through all characters.
		std::string::const_iterator c;
		for (c = coinsNumberText.begin(); c != coinsNumberText.end(); c++)
		{
			Character ch = oswaldCharacters[*c];

			GLfloat xpos = x + ch.bearing.v[0] * scale;
			GLfloat ypos = y - (ch.size.v[1] - ch.bearing.v[1]) * scale;

			GLfloat w = ch.size.v[0] * scale;
			GLfloat h = ch.size.v[1] * scale;
			// Update VBO for each character.
			GLfloat vertices[6][4] = {
				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos,     ypos,       0.0, 1.0 },
				{ xpos + w, ypos,       1.0, 1.0 },

				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos + w, ypos,       1.0, 1.0 },
				{ xpos + w, ypos + h,   1.0, 0.0 }
			};
			// Render glyph texture over quad.
			glBindTexture(GL_TEXTURE_2D, ch.textureID);
			// Update content of VBO memory.
			glBindBuffer(GL_ARRAY_BUFFER, textVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			// Render quad.
			glDrawArrays(GL_TRIANGLES, 0, 6);
			// Now advance cursors for next glyph (note that advance is number of 1/64 pixels).
			x += (ch.advance >> 6) * scale; // Bitshift by 6 to get value in pixels (2^6 = 64).
		}
		glBindVertexArray(0);
		glBindTexture(GL_TEXTURE_2D, 0);

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// End program.
	glfwTerminate();
	return 0;
}